import java.util.Scanner;
import java.util.Random;

public class PedraPapelTesoura {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        Random random = new Random();

        System.out.println("=== PEDRA, PAPEL OU TESOURA ===");
        System.out.println("1 - Pedra");
        System.out.println("2 - Papel");
        System.out.println("3 - Tesoura");
        System.out.print("Escolha sua jogada: ");

        int jogador = sc.nextInt();

        // Verifica se a escolha é válida antes de utilizá-la
        if (jogador < 1 || jogador > 3) {
            System.out.println("Escolha inválida!");
            sc.close();
            return;
        }

        // O computador escolhe um número entre 1 e 3
        int computador = random.nextInt(3) + 1;

        String[] opcoes = {"", "Pedra", "Papel", "Tesoura"};

        System.out.println("Você escolheu: " + opcoes[jogador]);
        System.out.println("Computador escolheu: " + opcoes[computador]);

        if (jogador == computador) {
            System.out.println("Empate!");
        } else if (
            (jogador == 1 && computador == 3) ||
            (jogador == 2 && computador == 1) ||
            (jogador == 3 && computador == 2)
        ) {
            System.out.println("Você venceu!");
        } else {
            System.out.println("O computador venceu!");
        }

        sc.close();
    }
}
